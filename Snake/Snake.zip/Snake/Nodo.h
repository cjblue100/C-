#pragma once

class Nodo
{
public:
	Nodo(){}

	Nodo* siguiente;
	Nodo* anterior;
};

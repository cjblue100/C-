#pragma once
#ifndef INICIO_H
#define INICIO_H
#include "Juego.h"

class Inicio
{
public:

	Inicio();
	~Inicio();

	void gotoxy(int x, int y);
	void drawI();


};







#endif
#pragma once
#include "Juego.h"
#ifndef DEATH_H
#define DEATH_H

class death
{
public:
	death();


	bool PGame(int);
	void gotoxy(int x, int y);
	void drawDeath(bool);
	

};




#endif